# FeatherW8 - сборка APK (кратко, по-русски)

В архиве - полный проект Android Studio/Gradle: исходники приложения, Gradle Wrapper
(включая gradle-wrapper.jar), нативный DSD->PCM декодер (C++/CMake) с его LGPL-2.1 лицензией.
Отдельный checkout dsd-nexus не нужен.

Версии, закреплённые проектом:

| Что | Версия |
| --- | --- |
| Gradle Wrapper | 9.4.1 |
| Android Gradle Plugin | 9.2.0 |
| Kotlin (compose plugin) | 2.3.10 |
| compileSdk | 37 |
| targetSdk | 36 |
| minSdk | 28 |
| NDK | 27.2.12479018 |
| CMake | 3.22.1 |
| ABI | только arm64-v8a |

## 1. Что должно быть установлено

- JDK 21 (в Android Studio: Gradle JDK = 21). Проверка: `java -version`
- Android SDK Platform `android-37.0`
- Android SDK Build Tools `36.0.0` или новее
- Android NDK `27.2.12479018`
- CMake `3.22.1`
- Интернет на первой сборке: Gradle сам скачает дистрибутив Gradle 9.4.1, AGP и зависимости
  (Compose BOM, Media3 и т.д.). Готового офлайн-кэша Maven в архиве нет.
- Желательно 8+ ГБ ОЗУ и несколько ГБ свободного места.

```sh
sdkmanager --licenses
sdkmanager "platforms;android-37.0" "build-tools;36.0.0" "ndk;27.2.12479018" "cmake;3.22.1"
```

Путь к SDK: переменная окружения `ANDROID_HOME` / `ANDROID_SDK_ROOT` либо файл
`local.properties` в корне проекта (см. `local.properties.example`).

## 2. Сборка debug APK

Linux / macOS:

```sh
./build-local.sh
```

Руками:

```sh
CMAKE_BUILD_PARALLEL_LEVEL=1 ./gradlew :app:testDebugUnitTest :app:assembleDebug --no-daemon --max-workers=1
```

Windows (PowerShell):

```powershell
$env:CMAKE_BUILD_PARALLEL_LEVEL = "1"
.\gradlew.bat :app:testDebugUnitTest :app:assembleDebug --no-daemon --max-workers=1
```

Результат: `app/build/outputs/apk/debug/app-debug.apk` (подписан отладочным ключом).

## 3. Release APK

```sh
./gradlew :app:assembleRelease --no-daemon --max-workers=1
apksigner sign --ks my-release-key.jks --out FeatherW8-release.apk app/build/outputs/apk/release/app-release-unsigned.apk
```

## 4. Частые проблемы

- `SDK location not found` -> `local.properties` рядом с `settings.gradle.kts` (шаблон - `local.properties.example`) или `ANDROID_HOME`.
- Ошибки CMake/NDK -> нужен ровно NDK `27.2.12479018` и CMake `3.22.1`; можно удалить `app/.cxx` и пересобрать.
- Первая сборка долгая - это CMake собирает vendored `libdsdpcm`, не прерывай.
- OutOfMemory у Gradle -> `--no-daemon --max-workers=1` (уже в `build-local.sh`) или подними `org.gradle.jvmargs`.
- На 32-битные устройства не установится: `abiFilters += listOf("arm64-v8a")`.

Подробнее (на английском) - в `BUILD_LOCAL.md`.
